import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AccordionModule} from 'primeng/accordion';
import {CarouselModule} from 'primeng/carousel';
import {ButtonModule} from 'primeng/button';
import {ToastModule} from 'primeng/toast';
import {EmployeeDataRoutingModule } from './employee-data-routing.module';
import {DialogModule} from 'primeng/dialog';
import {ConfirmationService, MessageService } from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { ReactiveFormsModule } from '@angular/forms';
import { EmployeeDataComponent } from './employee-data.component';
import {TableModule} from 'primeng/table';
import { FormsModule } from '@angular/forms';
import { FullnamePipe } from '../service/fullname.pipe';
import { Hover } from '../service/hover.directive';

@NgModule({
    imports: [
        CommonModule,
        EmployeeDataRoutingModule,
        AccordionModule,
        CarouselModule,
        ButtonModule,
        ToastModule,
        DialogModule,
        ConfirmDialogModule,
        ReactiveFormsModule,
        TableModule,
        FormsModule
        
    ],
    declarations: [EmployeeDataComponent,FullnamePipe,Hover],
    providers: [MessageService,ConfirmationService]
})
export class EmployeeDataModule {}
