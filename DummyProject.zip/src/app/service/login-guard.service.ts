import { Injectable } from '@angular/core';
import { Router, CanLoad } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class LoginGuard implements CanLoad {
  loggedIN:any;

  constructor(private router : Router) { 
   this.loggedIN = localStorage.getItem("token");
  }

  canLoad() {
    if(this.loggedIN){
      return true;
    }
    else{

    this.router.navigate(['/login-page']);
    return false;
    }
}

}

