import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Product } from '../model/product';
import { catchError, map, Observable, pipe, throwError } from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class DataService {

    constructor(private httpClient: HttpClient) { }

    getProductsSmall() {
        return this.httpClient.get<any>('assets/products-small.json')
        .toPromise()
        .then(res => <Product[]>res.data)
        .then(data => { return data; });
    }

    getEmployeeData(){
        return this.httpClient.get<any>('assets/employeeData.json').toPromise()
        .then(res => <any[]>res.data)
        .then(data => { return data; });
    }

    // getData(){
    //     return this.httpClient.get('/api/listUsers')
    //   }

      getData(): Observable<any> {
        return this.httpClient.get('http://localhost:3000/employee/getEmployeesData').pipe(
            map(
                (res: any) => {
                  console.log(res);
                  const data = {
                    datalist: res
                  };
                  return data;
                }
              ),
            catchError(this.handleError)
        );
    }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }
    
}