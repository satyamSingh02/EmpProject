import { Directive, ElementRef, HostListener } from "@angular/core";

@Directive({
    selector:'[row]'
})

export class Hover{
    constructor(private elRef: ElementRef) {
    }
    @HostListener('mouseover') onmouseover() {
    this.changeBackgroundColor("#00FF00");
    }
    @HostListener('mouseleave') onMouseLeave() {
    this.changeBackgroundColor('#FFFFFF');
    }
    private changeBackgroundColor(color: string) {
    this.elRef.nativeElement.style.backgroundColor = color;
    }
}