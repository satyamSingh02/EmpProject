import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fullname'
})
export class FullnamePipe implements PipeTransform {

  transform(value: string, seperator: string): string {
    console.log(value);
    
    let result = value.concat(seperator);
    console.log(result);
    
    return result;
  }

}
