import { Pipe, PipeTransform } from '@angular/core';
import { Employee } from '../model/employee';

@Pipe({
  name: 'fullname'
})
export class FullnamePipe implements PipeTransform {

  transform(value: Employee): string {
    console.log(value);
    
    let result = value.firstName + ' ' + value.lastName;
    console.log(result);
    
    return result;
  }

}
