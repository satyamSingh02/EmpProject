import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormControl, Validators } from '@angular/forms';
//import { MyserviceService } from '../myservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import jwt_decode, { } from 'jwt-decode'
import { EmpService } from '../service/employee.service';

import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  welcMsg: string | undefined;
  decoded:any;
  token:any;
  loginForm: any;
  errormsg:any;
  constructor(private myservice: EmpService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private messageService:MessageService
    ) {
    this.loginForm = new FormGroup({
      email: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });

  }

  ngOnInit() {
  }

  isValid(controlName: string) {
    return this.loginForm.get(controlName)?.invalid && this.loginForm.get(controlName)?.touched;
  }

  login() {
    
    if (this.loginForm.valid) {
      this.myservice.login(this.loginForm.value)
        .subscribe((data:any) => {
            console.log(data,"data")
            localStorage.setItem('token', data.toString());
           this.token = window.localStorage.getItem('token');
            this.decoded = jwt_decode(this.token)
            // console.log(this.decoded.username);
            
            this.welcMsg = `${ this.decoded.username ?  this.decoded.username : ''}`
            console.log(this.welcMsg);
            localStorage.setItem("name",this.welcMsg);
            
            this._router.navigate(['/home-page']);
          },
          error => { 
            this.errormsg = error.error.message;
            console.log(this.errormsg);
            this.messageService.add({severity:'Error', summary: 'UnSuccessful', detail: this.errormsg, life: 3000});
            
           }
        );
    }
  }

}

