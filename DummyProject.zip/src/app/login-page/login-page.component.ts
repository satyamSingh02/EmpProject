import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormControl, Validators } from '@angular/forms';
//import { MyserviceService } from '../myservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import jwt_decode, { } from 'jwt-decode'
import { EmpService } from '../service/employee.service';

import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  welcMsg: string | undefined;
  decoded:any;
  token:any;
  loginForm: any;
  constructor(private myservice: EmpService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute) {
    this.loginForm = new FormGroup({
      email: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });

  }

  ngOnInit() {
  }

  isValid(controlName: string) {
    return this.loginForm.get(controlName)?.invalid && this.loginForm.get(controlName)?.touched;
  }

  login() {
    
    if (this.loginForm.valid) {
      this.myservice.login(this.loginForm.value)
        .subscribe((data:any) => {
            console.log(data,"data")
            localStorage.setItem('token', data.toString());
           this.token = window.localStorage.getItem('token');
            this.decoded = jwt_decode(this.token)
            // console.log(this.decoded.username);
            
            this.welcMsg = `${ this.decoded.username ?  this.decoded.username : ''}`
            console.log(this.welcMsg);
            localStorage.setItem("name",this.welcMsg);
            
            this._router.navigate(['/home-page']);
          },
         // error => { }
        );
    }
  }

}

