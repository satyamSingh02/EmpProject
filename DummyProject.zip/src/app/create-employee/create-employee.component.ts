import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { Employee } from '../model/employee';
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.scss']
})
export class CreateEmployeeComponent implements OnInit {


  registerForm:any;
  display: boolean = false;
  arr:any[]=[];
  employee!: Employee;

  constructor(
    private formBuilder: FormBuilder, 
    private confirmationService: ConfirmationService,
    private router:Router,
    private dataService:DataService
    ) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      id: ['',[Validators.required, Validators.minLength(4), Validators.maxLength(6)]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      mobileNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
  }); 
}

  onSubmit(){
    if (this.registerForm.invalid) {
      this.display=true;
      this. confirmMthd1("Invalid Data, PLease enter correct data.")
      return;
    }
    this.employee=this.registerForm.value
    this.dataService.sendData(this.employee).subscribe(
      (data:any)=>{
        console.log(data);
        
      });
    
    console.log(this.employee);

    this.arr.push(this.registerForm.value);
   // localStorage.setItem("arr",JSON.stringify(this.arr));
    
    this.registerForm.reset();
    this.router.navigate(['/employee-data'])
  }
  confirmMthd1(type: string) {
    this.confirmationService.confirm({
      message: type
    });
  }
  okMth(){
    this.confirmationService.close();
  }
}
