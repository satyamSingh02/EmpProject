import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AccordionModule} from 'primeng/accordion';
import {CarouselModule} from 'primeng/carousel';
import {ButtonModule} from 'primeng/button';
import {ToastModule} from 'primeng/toast';
import { CreateEmployeeRoutingModule } from './create-employee-routing.module';
import {DialogModule} from 'primeng/dialog';
import { ConfirmationService } from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { ReactiveFormsModule } from '@angular/forms';
import { CreateEmployeeComponent } from './create-employee.component';

@NgModule({
    imports: [
        CommonModule,
        CreateEmployeeRoutingModule,
        AccordionModule,
        CarouselModule,
        ButtonModule,
        ToastModule,
        DialogModule,
        ConfirmDialogModule,
        ReactiveFormsModule
    ],
    declarations: [CreateEmployeeComponent],
    providers: [ConfirmationService]
})
export class CreateEmployeeModule {}
