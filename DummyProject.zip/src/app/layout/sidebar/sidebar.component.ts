import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  isActive = false;
  collapsed = false;
  showMenu = '';
  pushRightClass = 'push-right';
  logged:boolean=true;
  loggedOut:boolean=true;

  @Output() collapsedEvent = new EventEmitter<boolean>();
  constructor(
    private router:Router
  ) { }

  ngOnInit(): void {
    let value= window.localStorage.getItem("token");
    if(value==null||value==''||value==undefined){
  this.logged=true;
  this.loggedOut=false;}
  else{
  this.logged=false;
    this.loggedOut=true;
}
  }
  toggleCollapsed(){
    this.collapsed = !this.collapsed;
    this.collapsedEvent.emit(this.collapsed);
  }
  logout(){
     window.localStorage.removeItem("token");
    // window.localStorage.removeItem("name");
    localStorage.clear();
    //window.location.reload();
    this.router.navigate(['/login-page']);
    console.log("hello");
    
  }

  login(){
   let value= window.localStorage.getItem("token");
  
  this.router.navigate(['/login-page']);
  }
}
