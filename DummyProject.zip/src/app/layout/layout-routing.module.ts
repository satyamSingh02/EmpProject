import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from '../login-page/login-page.component';
import { AuthGuard } from '../service/auth-guard.service';
import { LoginGuard } from '../service/login-guard.service';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        
           

        children: [
            { path: '', redirectTo: 'home-page', pathMatch: 'prefix',  },
           
            {
                path: 'create-employee',
                loadChildren: () => import('../create-employee/create-employee.module')
                .then(m => m.CreateEmployeeModule),canLoad:[LoginGuard]
            },
            
            {
                path: 'home-page',
                loadChildren: () => import('../home-page/home-page.module')
                .then(m => m.HomePageComponentModule)
            },

            {
                path: 'employee-data',
                loadChildren: () => import('../employee-data/employee-data.module')
                .then(m => m.EmployeeDataModule),canLoad:[LoginGuard]
            }
            

          

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule { }
