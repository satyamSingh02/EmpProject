var express = require('express');
var router = express.Router();

var fs = require('fs');


router.get('/getEmployeesData', function (req, res) {
    fs.readFile('./employeeData.json', 'utf8', function (err, data) {
        if (!err) {
            console.log("Success" + data);
            res.end(data);
        } else {
            res.end("Error: " + err)
        }
    });
})

router.post('/mapData', function(req,res,next){
    debugger;
    const users = require('./employeeData');
    debugger;
    console.log(req.body);
    users.push(req.body);
    debugger;
    fs.writeFile('./employeeData.json', JSON.stringify(users, null , 2), err => {
       
        if (err) throw err; 
        debugger;
        console.log("Done writing");
    });
  })

router.post('/updateData', function(req,res,next){
   console.log(req.body.id);
   console.log(req.body);
   const users = require('../employeeData');
   const finalData = users.findIndex(value =>{
       console.log(value.id === req.body.id,"value");
        value.id === req.body.id
   
    });
    users(finalData)=req.body
    // fs.writeFile('../employeeData.json', JSON.stringify(users, null , 2), err => {
       
    //     if (err) throw err; 
    //     debugger;
    //     console.log("Done writing"); 
    // });
   console.log(finalData);
   console.log(users);

    });
  

module.exports = router;

