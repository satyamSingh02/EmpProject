var express = require('express');
var router = express.Router();
const fs = require("fs");
// // STEP 1: Reading JSON file
// const users = require("./employeeData");
   
// // Defining new user
// let user =
// {
//     id: "9999",
//     firstName: "Huge",
//     lastName: "Jack",
//     mobileNumber: "7766776677",
//     emailId: "huge@gmail.com"			
// }
   
// // STEP 2: Adding new data to users object
// users.push(user);
   
// // STEP 3: Writing to a file
// fs.writeFile("employeeData.json", JSON.stringify(users), err => {
     
//     // Checking for errors
//     if (err) throw err; 
   
//     console.log("Done writing"); // Success
// });

// router.post('/mapData', function(req,res,next){
//     console.log(req);
  
//   })
// const users = require('./employeeData');

// router.post('/mapData', function(req,res,next){

//     console.log(req);
//     users.push(req);
//     fs.writeFile('./employeeData.json', JSON.stringify(users), err => {
       
//         // Checking for errors
//         if (err) throw err; 
       
//         console.log("Done writing"); // Success
//     });
//   })


  module.exports = router;