import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from './layout/layout.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptorService } from './service/token-interceptor.service';
import { ReactiveFormsModule , FormsModule} from '@angular/forms';
import { LoginPageComponent } from './login-page/login-page.component';
import { FullnamePipe } from './service/fullname.pipe';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';

@NgModule({
  declarations: [
    AppComponent,LoginPageComponent
    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    LayoutModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    ToastModule
    
  ],
  providers: [  { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptorService, multi: true },
    MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
