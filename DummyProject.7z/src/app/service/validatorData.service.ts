
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class ValidatorDataService {
  private url = 'http://localhost:3000/employee/getEmailData/';
  EmpData:any;
  constructor(private http: HttpClient) {
    
   }
  
  getUserByEmail(email: string) {
    return this.http.get<any[]>(`${this.url}${email}`);
  }

getEmployeeData(value:any):Observable<any>{
  return this.http.get<any>('assets/employeeData.json').pipe(
    map(
      (res: any) => {
        const data = {
          datalist: res
        };
        for (let i=0; i<data.datalist.data.length; i++){
          for(let key in data.datalist.data[i]){
              if(key==="emailId"){
                  if(data.datalist.data[i][key] === value){
                    return data.datalist.data[i];
                  }
                }
                else if(key==="mobileNumber"){
                  if(data.datalist.data[i][key] === value){
                    return data.datalist.data[i];
                  }
                }
                else if(key==="id"){
                  if(data.datalist.data[i][key] === value){
                    return data.datalist.data[i];
                  }
                }
              }
            }
      }
    )
  )
    }

  getData(postData:any): Observable<any[]> {
    return this.http.post<any[]>('http://localhost:3000/employee/getEmailData', postData);
  }

 

}
