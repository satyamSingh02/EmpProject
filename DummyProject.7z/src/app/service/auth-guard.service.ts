
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  loggedIN:any;

  constructor(private router : Router) { 
   this.loggedIN = localStorage.getItem("token");
  }

  canActivate(
    _next: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): 
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
   
        if(!this.loggedIN){
            return true;
          }
    
          this.router.navigate(['/home-page']);
          return false;
      }
}

