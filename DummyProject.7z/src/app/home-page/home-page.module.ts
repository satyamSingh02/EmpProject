import { NgModule } from '@angular/core';
import { HomePageRoutingModule } from './home-page-routing.module';
import { CommonModule } from '@angular/common';
import { HomePageComponent } from './home-page.component';
import {AccordionModule} from 'primeng/accordion';
import {CarouselModule} from 'primeng/carousel';
import {ButtonModule} from 'primeng/button';
import { DataService } from '../service/data.service';
import {ToastModule} from 'primeng/toast';

@NgModule({
    imports: [
        CommonModule,
        HomePageRoutingModule,
        AccordionModule,
        CarouselModule,
        ButtonModule,
        ToastModule
       
    ],
    declarations: [HomePageComponent],
    providers:[DataService]
})
export class HomePageComponentModule {}
