import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  products: Product[] = [];
  responsiveOptions;

  constructor(
    private dataService :DataService,
    private httpClient:HttpClient
  ) {
    this.responsiveOptions = [
      {
          breakpoint: '1024px',
          numVisible: 3,
          numScroll: 3
      },
      {
          breakpoint: '768px',
          numVisible: 2,
          numScroll: 2
      },
      {
          breakpoint: '560px',
          numVisible: 1,
          numScroll: 1
      }
  ];
   }

  ngOnInit(): void {
    console.log("hiii");
    this.dataService.getProductsSmall().then(products => {
			this.products = products;
		});
    this.getApiData();
  }

  
  getApiData(){
    this.dataService.getData().subscribe((data:any)=>{
      console.log(data.data);
    //  this.products = data.data
      
    })
  }

}
