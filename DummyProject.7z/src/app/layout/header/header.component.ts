import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
wlcmessage:any;
  constructor() { }

  ngOnInit(): void {
    this.wlcmessage=localStorage.getItem("name")
    console.log(this.wlcmessage);
    
  }
  toggleSidebar(){}
}
