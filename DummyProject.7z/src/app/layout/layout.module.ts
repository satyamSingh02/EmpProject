import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {TooltipModule} from 'primeng/tooltip';
import {MessagesModule} from 'primeng/messages';
import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HeaderComponent } from './header/header.component';
import { HomePageComponent } from '../home-page/home-page.component';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    imports: [
        TooltipModule,
        MessagesModule,
        CommonModule,
        LayoutRoutingModule,
        ConfirmDialogModule,
        ReactiveFormsModule,
        FormsModule
    ],
    declarations: [LayoutComponent, SidebarComponent, HeaderComponent],
    entryComponents: [HomePageComponent]
})
export class LayoutModule {}
