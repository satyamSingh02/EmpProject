import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Employee } from '../model/employee';
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-employee-data',
  templateUrl: './employee-data.component.html',
  styleUrls: ['./employee-data.component.scss']
})
export class EmployeeDataComponent implements OnInit {

  cols: any[] = [];
  employeeData: Employee[]=[];
  employee!: Employee;
  createEmpData:any[] = [];

  constructor(
    private dataService:DataService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService
    ) { }

  ngOnInit(): void {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'firstName', header: 'First Name' },
      { field: 'lastName', header: 'Last Name' },
      { field: 'mobileNumber', header: 'Mobile Number' },
      { field: 'emailId', header: 'Email Id' },
      { field: 'fullName', header: 'Full Name' }
    ];

    //this.createEmpData = JSON.parse(localStorage.getItem("arr")!);
    
    // this.dataService.getEmployeeData().then(value => {
    //   value.push(this.createEmpData);
    //   this.employeeData=value;
    //   console.log(this.employeeData);
      
		// });
    
   this.getApiData();
  }

  getApiData(){
    this.dataService.getData().subscribe((data:any)=>{
    // if(this.createEmpData){
    //  for(let i=0; i< this.createEmpData.length;i++){
    //   data.datalist.data.push(this.createEmpData[i]);
    //  }
    // }
      this.employeeData = data.datalist
     console.log();
     
      
    })
  }


  onRowEditInit(prod: any){

  }
  onRowEditSave(rowData:any){
    console.log(rowData);
    // this.employee=rowData;
    // this.dataService.updateData(this.employee).subscribe(
    //   (data:any)=>{
    //     console.log(data);
        
    //   }
    //)

    
  }
  onRowDelete(empData:any){
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + empData.firstName + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.employeeData = this.employeeData.filter(val => val.id !== empData);
          console.log(this.employeeData);
          this.messageService.add({severity:'success', summary: 'Successful', detail: 'Product Deleted', life: 3000});
      }
  });
  }

}
